function getProductInfo() {
  const productName = document.querySelector('#productTitle').innerText;
  const productURL = window.location.href;

  // Fetch the product information from Flipkart
  fetch('https://www.flipkart.com/search?q=' + encodeURIComponent(productName))
    .then((response) => response.text())
    .then((data) => {
      if (data.includes(productName)) {
        const flipkartLink = 'https://www.flipkart.com/search?q=' + encodeURIComponent(productName);
        // const flipkartPrice = 'Extract the price from the fetched data, if available.';
        showPopup(productName, /*flipkartPrice*/ flipkartLink);
      }
    });

  // Fetch the product information from Tata Cliq
  fetch('https://www.tatacliq.com/search/?q=' + encodeURIComponent(productName))
    .then((response) => response.text())
    .then((data) => {
      if (data.includes(productName)) {
        const tataCliqLink = 'https://www.tatacliq.com/search/?q=' + encodeURIComponent(productName);
        // const tataCliqPrice = 'Extract the price from the fetched data, if available.';
        showPopup(productName, /*tataCliqPrice*/ tataCliqLink);
      }
    });

  // Fetch the product information from Croma
  fetch('https://www.croma.com/search/?text=' + encodeURIComponent(productName))
    .then((response) => response.text())
    .then((data) => {
      if (data.includes(productName)) {
        const cromaLink = 'https://www.croma.com/search/?text=' + encodeURIComponent(productName);
        // const cromaPrice = 'Extract the price from the fetched data, if available.';
        showPopup(productName, /*cromaPrice*/ cromaLink);
      }
    });

    // Fetch the product information from VijaySales
  fetch('https://www.vijaysales.com/search/' + encodeURIComponent(productName))
  .then((response) => response.text())
  .then((data) => {
    if (data.includes(productName)) {
      const VijaySalesLink = 'https://www.vijaysales.com/search/' + encodeURIComponent(productName);
      // const VijaySalesPrice = 'Extract the price from the fetched data, if available.';
      showPopup(productName, /*VijaySalesPrice*/ VijaySalesLink);
    }
  });

  // Fetch the product information from reliancedigital
  fetch('https://www.reliancedigital.in/search?q=' + encodeURIComponent(productName))
  .then((response) => response.text())
  .then((data) => {
    if (data.includes(productName)) {
      const reliancedigitalLink = 'https://www.reliancedigital.in/search?q=' + encodeURIComponent(productName);
      // const reliancedigitalPrice = 'Extract the price from the fetched data, if available.';
      showPopup(productName, /*reliancedigitalPrice*/ reliancedigitalLink);
    }
  });
}


// Call the function when the page is fully loaded
window.onload = getProductInfo;
// Function to get the product information
function getProductInfo() {
  const productName = document.querySelector('#productTitle'||'#B_NuCI').innerText;
  // const productURL = window.location.href;

  // The line below opens new tabs for each e-commerce website with search results for the product.
  window.open('https://www.flipkart.com/search?q=' + encodeURIComponent(productName));
  window.open('https://www.tatacliq.com/search/?q=' + encodeURIComponent(productName));
  window.open('https://www.croma.com/search/?text=' + encodeURIComponent(productName));
  window.open('https://www.vijaysales.com/search/' + encodeURIComponent(productName));
  window.open('https://www.reliancedigital.in/search?q=' + encodeURIComponent(productName));
}


